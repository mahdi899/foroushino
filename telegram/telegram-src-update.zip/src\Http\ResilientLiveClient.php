<?php

declare(strict_types=1);

namespace TelegramHost\Http;

use TelegramHost\Services\IranFailureReporter;
use TelegramHost\Telegram\BotApiClient;

/**
 * Live Iran API — sends typing to the user, reports outages to the reports group.
 */
final class ResilientLiveClient
{
    public function __construct(
        private readonly LiveClient $live,
        private readonly BotApiClient $api,
        private readonly IranFailureReporter $reporter,
    ) {}

    /** @param array<string, mixed> $update */
    public function processUpdate(array $update, int $chatId, int $telegramUserId): array
    {
        return $this->invoke($chatId, $telegramUserId, 'پردازش آپدیت روی سرور اصلی', fn () => $this->live->processUpdate($update));
    }

    /** @return array<string, mixed> */
    public function discountPreview(int $chatId, int $telegramUserId, int $productId, string $code): array
    {
        return $this->invoke($chatId, $telegramUserId, 'بررسی کد تخفیف', fn () => $this->live->discountPreview($telegramUserId, $productId, $code));
    }

    /** @return array<string, mixed> */
    public function checkoutZarinpal(int $chatId, int $telegramUserId, int $productId, ?string $coupon = null): array
    {
        return $this->invoke($chatId, $telegramUserId, 'شروع پرداخت زرین‌پال', fn () => $this->live->checkoutZarinpal($telegramUserId, $productId, $coupon));
    }

    /** @return array<string, mixed> */
    public function checkoutC2c(int $chatId, int $telegramUserId, int $productId, ?string $coupon = null): array
    {
        return $this->invoke($chatId, $telegramUserId, 'شروع پرداخت کارت‌به‌کارت', fn () => $this->live->checkoutC2c($telegramUserId, $chatId, $productId, $coupon));
    }

    /** @param array<string, mixed> $message */
    public function supportTryReply(int $chatId, int $telegramUserId, array $message): array
    {
        return $this->invoke($chatId, $telegramUserId, 'پاسخ پشتیبانی', fn () => $this->live->supportTryReply($telegramUserId, $message));
    }

    /** @return array<string, mixed> */
    public function supportPrepare(int $chatId, int $telegramUserId, string $category): array
    {
        return $this->invoke($chatId, $telegramUserId, 'شروع گفتگوی پشتیبانی', fn () => $this->live->supportPrepare($telegramUserId, $category));
    }

    /** @return array<string, mixed> */
    public function satOpen(int $chatId, int $telegramUserId): array
    {
        return $this->invoke($chatId, $telegramUserId, 'بخش سات', fn () => $this->live->satOpen($telegramUserId, $chatId));
    }

    /** @return array<string, mixed> */
    public function capacityCheck(int $chatId, int $telegramUserId, int $seminarId): array
    {
        return $this->invoke($chatId, $telegramUserId, 'بررسی ظرفیت سمینار', fn () => $this->live->capacityCheck($seminarId));
    }

    /**
     * @param  callable(): array<string, mixed>  $call
     * @return array<string, mixed>
     */
    private function invoke(int $chatId, int $telegramUserId, string $operation, callable $call): array
    {
        if ($chatId !== 0) {
            $this->api->sendChatAction($chatId, 'typing');
        }

        try {
            return $call();
        } catch (\Throwable $e) {
            $this->reporter->report($telegramUserId, $operation, $e->getMessage());

            return [
                'ok' => false,
                'offline' => true,
            ];
        }
    }
}
