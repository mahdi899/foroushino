<?php

declare(strict_types=1);

namespace TelegramHost\Handlers;

use TelegramHost\Account\AccountCache;
use TelegramHost\Account\AccountSyncCoordinator;
use TelegramHost\Cache\SyncCache;
use TelegramHost\Conversation\ConversationRepository;
use TelegramHost\Http\ResilientLiveClient;
use TelegramHost\Services\HostRegistrationFlow;
use TelegramHost\Services\MainMenu;
use TelegramHost\Services\MembershipGate;
use TelegramHost\Services\PurchaseFlow;
use TelegramHost\Support\CatalogPresenter;
use TelegramHost\Support\InlineButtons;
use TelegramHost\Support\TelegramCustomEmoji;
use TelegramHost\Telegram\BotApiClient;

final class MessageHandler
{
    public function __construct(
        private readonly BotApiClient $api,
        private readonly SyncCache $cache,
        private readonly ResilientLiveClient $live,
        private readonly ConversationRepository $conversations,
        private readonly AccountCache $accounts,
        private readonly MainMenu $mainMenu,
        private readonly MembershipGate $membership,
        private readonly PurchaseFlow $purchaseFlow,
        private readonly HostRegistrationFlow $registration,
        private readonly AccountSyncCoordinator $accountSync,
        private readonly string $siteBaseUrl,
    ) {}

    /** @param array<string, mixed> $message */
    public function handle(array $message): void
    {
        $chatId = (int) $message['chat']['id'];
        $telegramUserId = (int) ($message['from']['id'] ?? 0);
        $text = trim((string) ($message['text'] ?? ''));

        if ($telegramUserId <= 0) {
            return;
        }

        if (isset($message['contact'])) {
            if ($this->accounts->isVerified($telegramUserId)) {
                $this->sendMainMenu($chatId, $telegramUserId);

                return;
            }
            $this->registration->contact($chatId, $telegramUserId, (array) $message['contact']);

            return;
        }

        if (isset($message['reply_to_message'])) {
            $reply = $this->live->supportTryReply($chatId, $telegramUserId, $message);
            if (! empty($reply['handled'])) {
                return;
            }
            if (! empty($reply['offline'])) {
                $this->api->sendMessage($chatId, $this->cache->message(
                    'support_message_received',
                    'پیام شما ثبت شد. به محض اتصال، برای پشتیبانی ارسال می‌شود.',
                ));

                return;
            }
        }

        $conversation = $this->conversations->get($telegramUserId);

        if ($text === '/start' || str_starts_with($text, '/start ')) {
            $startPayload = str_starts_with($text, '/start ') ? trim(substr($text, 7)) : null;
            $this->handleStart($chatId, $telegramUserId, (array) ($message['from'] ?? []), $startPayload !== '' ? $startPayload : null);

            return;
        }

        if ($conversation['state'] === 'waiting_for_name' && $text !== '') {
            $this->registration->name($chatId, $telegramUserId, $text);

            return;
        }

        if ($conversation['state'] === 'waiting_for_otp' && $text !== '') {
            $mobile = (string) ($conversation['context']['mobile'] ?? '');
            $this->registration->verifyOtp($chatId, $telegramUserId, $mobile, $text);

            return;
        }

        if ($conversation['state'] === 'waiting_for_support_message') {
            $this->api->sendMessage($chatId, $this->cache->message(
                'support_message_received',
                'پیام شما ثبت شد. به محض اتصال، برای پشتیبانی ارسال می‌شود.',
            ));

            return;
        }

        if ($conversation['state'] === 'waiting_for_card_to_card_receipt') {
            $this->api->sendMessage($chatId, $this->cache->message(
                'c2c_receipt_received',
                'رسید دریافت شد و در صف ثبت سفارش است.',
            ));

            return;
        }

        if ($text !== '' && $this->mainMenu->isMenuButton($text)) {
            // Local cache first — instant reply. Iran sync happens in the
            // background after the reply is sent (see HostBackgroundSync in
            // webhook.php), so button presses never block on a network call.
            $this->handleMenuButton($chatId, $telegramUserId, $text, (array) ($message['from'] ?? []));

            return;
        }

        if ($conversation['state'] === 'waiting_for_discount_code' && $text !== '') {
            $this->purchaseFlow->applyDiscountCode($chatId, $telegramUserId, $text);

            return;
        }

        $this->api->sendMessage($chatId, $this->cache->message('main_menu_hint', 'از دکمه‌های منو استفاده کنید.'), [
            'reply_markup' => $this->mainMenu->replyMarkup($telegramUserId),
        ]);
    }

    /**
     * @param array<string, mixed> $from
     */
    private function handleStart(int $chatId, int $telegramUserId, array $from = [], ?string $startPayload = null): void
    {
        if ($this->accounts->isVerified($telegramUserId)) {
            $this->sendMainMenu($chatId, $telegramUserId);

            return;
        }

        // Ask for the phone number immediately from local cache — no blocking
        // Iran round-trip. If this Telegram user already has a verified
        // account on Iran, the background sync triggered after this reply
        // (see HostBackgroundSync in webhook.php) picks it up within this
        // same request, so the very next button press already sees it.
        $this->registration->showLocalWelcome($chatId, $telegramUserId);
    }

    private function handleMenuButton(int $chatId, int $telegramUserId, string $text, array $from = []): void
    {
        if (! $this->accounts->isVerified($telegramUserId)) {
            $this->handleStart($chatId, $telegramUserId, $from);

            return;
        }

        if (! $this->membership->isSatisfied($telegramUserId)) {
            $this->api->sendMessage($chatId, $this->cache->message('membership_required', 'ابتدا در کانال‌های اجباری عضو شوید.'), [
                'reply_markup' => $this->membership->joinPromptMarkup(),
            ]);

            return;
        }

        $action = $this->mainMenu->resolveAction($text);
        match ($action) {
            MainMenu::ACTION_COURSES => $this->sendCourseList($chatId, $telegramUserId),
            MainMenu::ACTION_SEMINARS => $this->sendSeminarList($chatId, $telegramUserId),
            MainMenu::ACTION_SAT => $this->openSat($chatId, $telegramUserId),
            MainMenu::ACTION_CHANNEL => $this->sendReferenceChannel($chatId),
            MainMenu::ACTION_FAMILY => $this->sendFamily($chatId, $telegramUserId),
            MainMenu::ACTION_REFERRAL => $this->sendReferral($chatId, $telegramUserId),
            MainMenu::ACTION_SUPPORT => $this->openSupportHub($chatId),
            MainMenu::ACTION_ACCOUNT => $this->sendAccount($chatId, $telegramUserId),
            default => $this->sendMainMenu($chatId, $telegramUserId),
        };
    }

    private function sendMainMenu(int $chatId, int $telegramUserId): void
    {
        $this->api->sendMessage($chatId, $this->cache->message('main_menu_hint', 'منوی اصلی آکادمی بهرام'), [
            'reply_markup' => $this->mainMenu->replyMarkup($telegramUserId),
        ]);
    }

    private function sendCourseList(int $chatId, int $telegramUserId): void
    {
        $courses = $this->cache->courses();
        if ($courses === []) {
            $this->api->sendMessage($chatId, $this->cache->message('purchase_catalog_empty', 'هنوز دوره‌ای فعال نیست.'));

            return;
        }

        $lines = [TelegramCustomEmoji::tag('graduation').' <b>دوره‌های فعال</b>', ''];
        $keyboard = [];
        foreach (array_slice($courses, 0, 12) as $course) {
            $productId = (int) $course['id'];
            $title = trim((string) ($course['title'] ?? 'دوره'));
            $price = isset($course['sale_price']) && (int) $course['sale_price'] > 0
                ? (int) $course['sale_price']
                : (int) ($course['price'] ?? 0);
            $lines[] = '• '.htmlspecialchars($title, ENT_QUOTES | ENT_HTML5, 'UTF-8')
                .($price > 0 ? ' — '.number_format($price).' تومان' : '');
            $keyboard[] = [InlineButtons::buy($productId, mb_substr($title, 0, 28))];
        }

        $this->api->sendMessage($chatId, implode("\n", $lines), [
            'parse_mode' => 'HTML',
            'reply_markup' => ['inline_keyboard' => $keyboard],
        ]);
    }

    private function sendSeminarList(int $chatId, int $telegramUserId): void
    {
        $seminars = $this->cache->seminars();
        if ($seminars === []) {
            $this->api->sendMessage($chatId, $this->cache->message('seminars_catalog_empty', 'سمیناری برای نمایش نیست.'));

            return;
        }

        $lines = [TelegramCustomEmoji::tag('mic').' <b>سمینارها</b>', ''];
        $keyboard = [];
        foreach (array_slice($seminars, 0, 8) as $seminar) {
            $productId = (int) ($seminar['product_id'] ?? 0);
            $title = trim((string) ($seminar['title'] ?? 'سمینار'));
            $capacityHint = $seminar['capacity_hint'] ?? null;
            $capacitySuffix = '';
            if ($capacityHint !== null && $capacityHint !== '') {
                $capacitySuffix = (int) $capacityHint > 0
                    ? ' — '.number_format((int) $capacityHint).' صندلی باقی‌مانده'
                    : ' — ظرفیت تکمیل';
            }
            $lines[] = '• '.htmlspecialchars($title, ENT_QUOTES | ENT_HTML5, 'UTF-8').$capacitySuffix;
            // No separate "check capacity" step — capacity is already synced
            // locally from Iran, so tapping the seminar goes straight to the
            // purchase flow (which re-verifies with Iran at payment time).
            if ($productId > 0) {
                $keyboard[] = [InlineButtons::buy($productId, 'ثبت‌نام / '.mb_substr($title, 0, 18))];
            }
        }

        $this->api->sendMessage($chatId, implode("\n", $lines), [
            'parse_mode' => 'HTML',
            'reply_markup' => ['inline_keyboard' => $keyboard],
        ]);
    }

    /** @param array<string, mixed> $present */
    private function sendProductView(int $chatId, array $present): void
    {
        $text = (string) ($present['text'] ?? '');
        $options = (array) ($present['options'] ?? []);
        if (! isset($options['parse_mode'])) {
            $options['parse_mode'] = 'HTML';
        }
        $photo = (string) ($present['photo'] ?? '');

        if ($photo !== '') {
            $this->api->sendPhoto($chatId, $photo, $text, $options);
        } else {
            $this->api->sendMessage($chatId, $text, $options);
        }
    }

    private function openSat(int $chatId, int $telegramUserId): void
    {
        $result = $this->live->satOpen($chatId, $telegramUserId);
        if (! empty($result['state'])) {
            $this->conversations->set($telegramUserId, (string) $result['state'], (array) ($result['context'] ?? []));
        }

        if (empty($result['ok'])) {
            if (! empty($result['offline'])) {
                $url = $this->cache->siteUrl('sat', $this->siteBaseUrl.'/sat');
                $this->api->sendMessage($chatId, $this->cache->message(
                    'sat_use_site',
                    'فرم سات را از طریق لینک زیر تکمیل کنید:',
                ), [
                    'reply_markup' => ['inline_keyboard' => [[InlineButtons::url('ثبت‌نام سات', $url, 'bell', 'primary')]]],
                ]);

                return;
            }
            $this->api->sendMessage($chatId, (string) ($result['message'] ?? 'بخش سات در دسترس نیست.'));

            return;
        }

        if (! empty($result['text'])) {
            $options = (array) ($result['options'] ?? []);
            if (! isset($options['parse_mode'])) {
                $options['parse_mode'] = 'HTML';
            }
            $this->api->sendMessage($chatId, (string) $result['text'], $options);
        }
    }

    private function sendReferenceChannel(int $chatId): void
    {
        $url = $this->cache->siteUrl('identity', $this->siteBaseUrl.'/identity');
        $text = $this->cache->message('purchase_need_course', 'برای دسترسی به کانال مرجع، احراز هویت سطح ۲ لازم است.');
        $this->api->sendMessage($chatId, $text, [
            'reply_markup' => ['inline_keyboard' => [[InlineButtons::url('احراز هویت سطح ۲', $url, 'lock', 'primary')]]],
        ]);
    }

    private function sendFamily(int $chatId, int $telegramUserId): void
    {
        $result = $this->accounts->familyResponse($telegramUserId);
        if ($result === null || empty($result['text'])) {
            $this->api->sendMessage($chatId, $this->cache->message(
                'account_snapshot_pending',
                'اطلاعات خانواده هنوز همگام نشده. چند لحظه بعد دوباره «خانواده» را بزنید.',
            ));

            return;
        }
        if (empty($result['ok']) && isset($result['message'])) {
            $this->api->sendMessage($chatId, (string) $result['message']);

            return;
        }

        $this->api->sendMessage($chatId, (string) $result['text'], [
            'reply_markup' => (array) ($result['reply_markup'] ?? []),
        ]);
    }

    private function sendReferral(int $chatId, int $telegramUserId): void
    {
        if (! $this->cache->featureEnabled('referral_enabled')) {
            $this->api->sendMessage($chatId, 'این بخش فعلاً غیرفعال است.');

            return;
        }

        $result = $this->accounts->referralResponse($telegramUserId);
        if ($result === null) {
            $this->api->sendMessage($chatId, $this->cache->message(
                'account_snapshot_pending',
                'اطلاعات معرفی هنوز همگام نشده. چند لحظه بعد دوباره امتحان کنید.',
            ));

            return;
        }
        if (empty($result['ok'])) {
            $this->api->sendMessage($chatId, (string) ($result['message'] ?? 'لینک معرفی در دسترس نیست.'));

            return;
        }

        $this->api->sendMessage($chatId, (string) $result['text'], [
            'reply_markup' => (array) ($result['reply_markup'] ?? []),
        ]);
    }

    private function openSupportHub(int $chatId): void
    {
        $this->api->sendMessage($chatId, $this->cache->message('support_prompt', 'دسته پشتیبانی را انتخاب کنید:'), [
            'reply_markup' => [
                'inline_keyboard' => [
                    [[InlineButtons::callback($this->cache->message('support_category_purchase', 'خرید و پرداخت'), 'support:cat:purchase', 'cart', 'primary')]],
                    [[InlineButtons::callback($this->cache->message('support_category_campaign_course', 'دوره کمپین‌نویسی'), 'support:cat:campaign_course', 'graduation')]],
                    [[InlineButtons::callback($this->cache->message('support_category_sat', 'سات'), 'support:cat:sat', 'bell')]],
                    [[InlineButtons::callback($this->cache->message('support_category_other', 'سایر'), 'support:cat:other', 'chat')]],
                ],
            ],
        ]);
    }

    private function sendAccount(int $chatId, int $telegramUserId): void
    {
        $result = $this->accounts->profileResponse($telegramUserId);
        if ($result !== null && ! empty($result['ok'])) {
            $this->api->sendMessage($chatId, (string) $result['text'], (array) ($result['options'] ?? [
                'parse_mode' => 'HTML',
            ]));

            return;
        }

        $row = $this->accounts->get($telegramUserId);
        if ($row !== null && ! empty($row['display_name'])) {
            $lines = [
                TelegramCustomEmoji::tag('user').' <b>'.htmlspecialchars((string) $row['display_name'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').'</b>',
            ];
            if (! empty($row['mobile'])) {
                $lines[] = 'موبایل: <code>'.htmlspecialchars((string) $row['mobile'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').'</code>';
            }
            $this->api->sendMessage($chatId, implode("\n", $lines), ['parse_mode' => 'HTML']);

            return;
        }

        $this->api->sendMessage($chatId, $this->cache->message(
            'account_snapshot_pending',
            'اطلاعات حساب هنوز همگام نشده. چند لحظه بعد دوباره «حساب من» را بزنید.',
        ));
    }
}
