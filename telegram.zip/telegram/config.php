<?php

declare(strict_types=1);

return [
    'sync_base_url' => 'https://rostami.app/api/v1/integrations/telegram-host',
    'hmac_secret' => 'Z9yytOziwzH95NjyTzE15tIqG90bi58fCPoUcXUePiwYQsOaCfIisozxDD4gjdhD',
    'aes_key' => 'Gu2SMs2Mv2OLcZUDvCtf2kdxVIapR8vDaVbz+9bcrAo=',
    'proxy_origin' => 'Telegram-Host-App',
    'server_push_origin' => 'Main-Server',
    'host_public_url' => 'https://bahram.rahai.online/bahram',
    'webhook_secret' => 'iGZmon1E5364a9DofD52snaT8LauUdKv',
    'bot_token' => '8955330613:AAGcu3wdR7FyfDBiy-ZGwC8hzCdNpJRjTFs',
    'site_base_url' => 'https://rostami.app',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'bahramra_masterdbbot',
        'username' => 'bahramra_EGh_bot_barm',
        'password' => '6qi&rJ(stT^Tju&}N$',
        'charset' => 'utf8mb4',
    ],
    'cache_ttl_seconds' => 300,
];
